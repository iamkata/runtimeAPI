//
//  main.m
//  Interview02-runtime应用
//
//  Created by MJ Lee on 2018/5/29.
//  Copyright © 2018年 MJ Lee. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MJPerson.h"
#import "MJStudent.h"
#import "MJCar.h"
#import <objc/runtime.h>
#import "NSObject+Json.h"

void run(id self, SEL _cmd)
{
    NSLog(@"_____ %@ - %@", self, NSStringFromSelector(_cmd));
}

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        
        // 字典转模型
        NSDictionary *json = @{
                               @"id" : @20,
                               @"age" : @20,
                               @"weight" : @60,
                               @"name" : @"Jack"
//                               @"no" : @30
                               };

        MJPerson *person = [MJPerson mj_objectWithJson:json];

//        [MJCar mj_objectWithJson:json];

//        MJStudent *student = [MJStudent mj_objectWithJson:json];

        NSLog(@"123");
        NSLog(@"%@",person.name);
        
    }
    return 0;
}


void testIvars()
{
    //获取成员变量信息
    //传入的是一个类对象，所以只能获取成员变量的信息，并不能获取成员变量的值。
    Ivar ageIvar = class_getInstanceVariable([MJPerson class], "_age");
    Ivar nameIvar = class_getInstanceVariable([MJPerson class], "_name");

    NSLog(@"%s %s", ivar_getName(ageIvar), ivar_getTypeEncoding(ageIvar));
    //打印：_age i   i代表字符编码int

    //设置成员变量的值
    //传入的是一个实例对象，所以可以设置成员变量的值
    MJPerson *person = [[MJPerson alloc] init];
    object_setIvar(person, nameIvar, @"123");
    id name = object_getIvar(person, nameIvar);
    
    object_setIvar(person, ageIvar, (__bridge id)(void *)10);
    
    NSLog(@"%@ %d", name, person.age);
    //打印：123 10
    
    // 获取成员变量数组
    unsigned int count;// 成员变量的数量
    Ivar *ivars = class_copyIvarList([MJPerson class], &count);
    for (int i = 0; i < count; i++) {
        // 取出i位置的成员变量
        Ivar ivar = ivars[i];
        NSLog(@"%s %s", ivar_getName(ivar), ivar_getTypeEncoding(ivar));
    }
    free(ivars);
//    2019-12-11 10:45:07.943080+0800 Interview02-runtime应用[39892:3040697] _ID i
//    2019-12-11 10:45:07.943242+0800 Interview02-runtime应用[39892:3040697] _weight i
//    2019-12-11 10:45:07.943250+0800 Interview02-runtime应用[39892:3040697] _age i
//    2019-12-11 10:45:07.943256+0800 Interview02-runtime应用[39892:3040697] _name @"NSString"
}

void testClass()
{
    // 创建类，传入父类和类名
    Class newClass = objc_allocateClassPair([NSObject class], "MJDog", 0);
    class_addIvar(newClass, "_age", 4, 1, @encode(int));
    class_addIvar(newClass, "_weight", 4, 1, @encode(int));
    class_addMethod(newClass, @selector(run), (IMP)run, "v@:");
    // 注册类之前添加方法
    objc_registerClassPair(newClass);
    
    id dog = [[newClass alloc] init];
    [dog setValue:@10 forKey:@"_age"];
    [dog setValue:@20 forKey:@"_weight"];
    [dog run];
    
    NSLog(@"%@ %@", [dog valueForKey:@"_age"], [dog valueForKey:@"_weight"]);
    
    MJPerson *person = [[MJPerson alloc] init];
    //修改person对象isa指向
    object_setClass(person, newClass);
    [person run];
    
    //_____ <MJDog: 0x10053a150> - run
    // 10 20
    //_____ <MJDog: 0x102008520> - run
    
    // 在不需要这个类时释放
    objc_disposeClassPair(newClass);
}

void test()
{
    MJPerson *person = [[MJPerson alloc] init];
    [person run]; //-[MJPerson run]

    //修改person对象isa的指向，指向MJCar类对象
    object_setClass(person, [MJCar class]);
    //person变成MJCar类型的，会去MJCar类对象里面寻找方法，最后调用-[MJCar run]
    [person run]; //-[MJCar run]

    NSLog(@"%d %d %d",
          object_isClass(person),// 0 person是实例对象，不是类对象
          object_isClass([MJPerson class]),// 1 是类对象
          object_isClass(object_getClass([MJPerson class]))// 1 是类对象(元类对象也是一种特殊的类对象)
          );

    NSLog(@"%p %p %p",object_getClass(person),object_getClass([MJPerson class]), [MJPerson class]); //0x100002700 0x100002728 0x100002750
    //打印的分别是：MJCar类对象的地址，MJPerson元类对象的地址，MJPerson类对象的地址
}
