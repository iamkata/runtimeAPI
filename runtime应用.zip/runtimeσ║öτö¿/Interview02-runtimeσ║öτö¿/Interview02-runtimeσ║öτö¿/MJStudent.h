//
//  MJStudent.h
//  Interview02-runtime应用
//
//  Created by MJ Lee on 2018/5/29.
//  Copyright © 2018年 MJ Lee. All rights reserved.
//

#import "MJPerson.h"

@interface MJStudent : MJPerson
@property (assign, nonatomic) int no;
@end
